package com.example.dockerize.springbootapp.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.dockerize.springbootapp.data.document.Documents;
import com.example.dockerize.springbootapp.data.document.IdentityDocumentId;
import com.example.dockerize.springbootapp.service.DocumentService;
import com.example.dockerize.springbootapp.service.SequenceGeneratorService;

@RestController
@RequestMapping("/api/todo")
public class TodoController {

	@Autowired
	private final DocumentService documentService = null;

	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;

	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	@CrossOrigin(origins = "http://localhost:8080")
	public Documents save(@RequestBody Documents entity) {
		// TODO Auto-generated method stub
		System.out.println("created");
		try {
			System.out.println("insert");
			ModelMapper modelMapper = new ModelMapper();
			Documents obj = modelMapper.map(entity, Documents.class);
			obj.setId(sequenceGeneratorService.getSequenceNumber("user_sequence") + 1);
			documentService.save(obj);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	@RequestMapping(method = RequestMethod.GET)
	@CrossOrigin(origins = "http://localhost:8080")
	List<Documents> findAll() {
		for (Documents a : documentService.getAll()) {

		}
		return documentService.getAll();
	}

	@RequestMapping(method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.ACCEPTED)
	@CrossOrigin(origins = "*")
	List<Documents> delete(@RequestBody IdentityDocumentId id) {
		documentService.delete(id.getId().longValue());
		return documentService.getAll();
	}

	@RequestMapping(method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.CREATED)
	@CrossOrigin(origins = "http://localhost:8080")
	public Documents update(@RequestBody Documents entity) {
		// TODO Auto-generated method stub
		System.out.println("updated");
		try {
			System.out.println(entity.getIdentityDocument().getEmissionDate());
			System.out.println("insert");
			ModelMapper modelMapper = new ModelMapper();
			Documents obj = modelMapper.map(entity, Documents.class);
			documentService.save(obj);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

}