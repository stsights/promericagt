package com.example.dockerize.springbootapp.service;

import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.example.dockerize.springbootapp.data.document.DbSequence;

@Service
public class SequenceGeneratorServiceImpl implements SequenceGeneratorService {

	@Autowired
	private MongoOperations mongoOperations;

	public int getSequenceNumber(String sequenceName) {
		// get sequence no
		Query query = new Query(Criteria.where("_id").is(sequenceName));
		System.out.println(query);
		// update the sequence no
		Update update = new Update().inc("seq", 1);
		// modify in document
		DbSequence counter = mongoOperations.findAndModify(query, update, options().returnNew(true).upsert(true),
				DbSequence.class);
		System.out.println(counter.getSeq());

		return counter.getSeq();
	}

}
