package com.example.dockerize.springbootapp.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.dockerize.springbootapp.data.document.Documents;

public interface TodoRepository extends MongoRepository<Documents, Long> {
}
