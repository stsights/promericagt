package com.example.dockerize.springbootapp.service;

import java.math.BigInteger;

import org.springframework.stereotype.Service;

@Service
public interface SequenceGeneratorService {
	int getSequenceNumber(String sequenceName);
}
