package com.example.dockerize.springbootapp.model;

import com.example.dockerize.springbootapp.data.document.DocumentType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public final class Todo {
	private String id;
	private String identityDocument;
	private String number;
	private String expiryDate;
	private String emissionDate;
	private DocumentType documentType;
}