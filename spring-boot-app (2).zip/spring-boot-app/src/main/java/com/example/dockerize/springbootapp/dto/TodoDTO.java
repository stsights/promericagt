package com.example.dockerize.springbootapp.dto;

import java.util.List;

import com.example.dockerize.springbootapp.data.document.DocumentType;

public final class TodoDTO {

	private String number;
	private String expiryDate;
	private String emissionDate;
	private List<DocumentType> documentType;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getEmissionDate() {
		return emissionDate;
	}

	public void setEmissionDate(String emissionDate) {
		this.emissionDate = emissionDate;
	}

	public List<DocumentType> getDocumentType() {
		return documentType;
	}

	public void setDocumentType(List<DocumentType> documentType) {
		this.documentType = documentType;
	}

}