package com.example.dockerize.springbootapp.service;

import com.example.dockerize.springbootapp.data.document.Documents;
import com.example.dockerize.springbootapp.utilities.ServiceAPI;

public interface DocumentService extends ServiceAPI<Documents, Long> {
}
