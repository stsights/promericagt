package com.example.dockerize.springbootapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.example.dockerize.springbootapp.data.document.Documents;
import com.example.dockerize.springbootapp.repository.TodoRepository;
import com.example.dockerize.springbootapp.utilities.ServiceImpl;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DocumentServiceImpl extends ServiceImpl<Documents, Long> implements DocumentService {

	@Autowired
	private final TodoRepository documentRepository= null;

	@Override
	public CrudRepository<Documents, Long> getDao() {
		return documentRepository;
	}
}